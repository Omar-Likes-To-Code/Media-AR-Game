## Low Poly 3D Chest Customizable plus Shattered


*THANK YOU FOR YOUR SUPPORT!*

### Short Description

Low Poly 3D Chest Customizable plus Shattered includes:
- 1 ChestCustomizable prefab
- 16 Variations, you can create more by mixing top+bottom+lock parts inside ChestCustomizable prefab
- 16 Materials
- 1 ShatterableChest prefab

### How to test the Shatter effect:
1. Open `DemoScene`
2. Run game
3. Click on the `ShatterabledChest` object in the game window

### How to apply URP material:
1. Go to `Edit` → `Render Pipeline` → `Universal Render Pipeline` → `Upgrade Project Materials to URP Materials`

Or

1. Select needed materials from the material folder
2. Go to `Edit` → `Render Pipeline` → `Universal Render Pipeline` → `Upgrade Selected Project Materials to URP Materials`


*If you have further problems, don’t hesitate to mail to dilarysherr@gmail.com*