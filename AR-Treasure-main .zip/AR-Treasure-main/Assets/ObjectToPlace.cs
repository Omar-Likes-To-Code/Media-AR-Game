using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

public class ObjectToPlace : MonoBehaviour
{
    public GameObject indicator; // The object you want to place on the plane
    public ARRaycastManager arRaycastManager;
    private List<ARRaycastHit> hits = new List<ARRaycastHit>();

    public float height;
    public Text text;

    void Update()
    {
        var ray = new Vector2(Screen.width / 2, Screen.height / 2);
        if (arRaycastManager.Raycast(ray, hits, TrackableType.Planes))
        {
            Pose pose = hits[0].pose;

            indicator.transform.position = pose.position;
            indicator.transform.rotation = pose.rotation;
            indicator.SetActive(true);
        }
        else
            indicator.SetActive(false);
    }

}
