using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Treasure : MonoBehaviour
{
    public Transform[] points;
    public Box treasurePrefab;
    public int treasureCount = 3;
    public Text text;
    public Text count;
    static int totalCount = 0;
    public Box[] chests;
    public float timer = 10;
    public int totalMax = 3;
    public Transform indicator;
    private void Awake()
    {
        totalCount = 0;
        Spawn();
    }
    public void Spawn()
    {

        for (int i = 0; i < 5; i++)
        {
            int random = Random.Range(0, points.Length);

            Box tresureBox = Instantiate(treasurePrefab, points[random].position, points[random].rotation);
            tresureBox.indicator = indicator;
        }
    }

    private void Update()
    {
        if(FindObjectsOfType<Box>().Length < totalMax)
        {
            timer -= Time.deltaTime;
            if(timer <0)
            {
                timer = 10;
                int random = Random.Range(0, points.Length);
                Instantiate(treasurePrefab, points[random].position, points[random].rotation);
            }
        }
    }

    public void RestartGame()
    {
        SceneManager.LoadScene(0);
    }

    public void GameQuit()
    {
        Application.Quit();
    }

    public async static void msg()
    {
        totalCount++;
        FindObjectOfType<Treasure>().text.text = "Treasure Found";
        FindObjectOfType<Treasure>().count.text = "Total Treasures: " + totalCount;
        await delay(2);
        FindObjectOfType<Treasure>().text.text = "";
    }

    static Task delay(float seconds)
    {
        return Task.Delay((int)(seconds * 1000));
    }
}
