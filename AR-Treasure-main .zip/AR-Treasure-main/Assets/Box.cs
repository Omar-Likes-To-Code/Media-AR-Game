using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class Box : MonoBehaviour
{
    public Transform pivot;
    public Transform indicator;
    public Text text;
    private Text distanceText;

    private void Start()
    {
        Transform grid = GameObject.Find("Grid").transform;
        distanceText = Instantiate(text, grid);
    }
    private void OnMouseDown()
    {
        Treasure.msg();
        transform.DOScale(2, 1).SetEase(Ease.OutBounce);
        pivot.DORotate(new Vector3(120, 0, 0), 2).SetEase(Ease.InExpo).OnComplete(() =>
        {
            Destroy(gameObject, 1);
        }
        );
        GetComponent<AudioSource>().Play();
        Destroy(distanceText);

    }

    private void Update()
    {
        float dist = Vector3.Distance(indicator.position, transform.position);
        if(distanceText)
            distanceText.text = "Distance: " + dist.ToString("0.00") + "cm";
    }
}
